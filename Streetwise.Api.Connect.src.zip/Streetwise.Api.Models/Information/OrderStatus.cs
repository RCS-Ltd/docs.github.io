﻿namespace Streetwise.Api.Models
{
    public enum OrderStatus
    {        
        New = 1,   //Order Received
        InPicking = 2, // transfered to WMS
        PickingComplete = 3, // picking done
        ToTransfer = 4, // waiting external notification
        Transfered = 5, // external notification sent ( Shipment received from WMS )
        PriceConfirmed = 6, // external notification accepted ( Shipment sent to Online store ) 
        Completed = 7,
        ToDelete = 8,
        Deleted = 9,
        ToRefund = 10,
        Refunded = 11
    }

    public enum OrderItemStatus
    {
        InsufficientStock = 0,
        ToPick = 1,  //new no actions taken
        InPicking = 2, // with warehouse or store
        PickingComplete = 3, // ready for dispatch
        ToTransfer = 4, // waiting for enternal notification
        Transfered = 5, // xternal notification sent ( Shipment received from WMS )
        PickConfirmed = 6, // external notification accepted ( Shipment sent to Online store ) 
        Complete = 7,
        ToDelete = 8,
        Deleted = 9,
        ToRefund = 10,
        Refunded = 11
    }
}
