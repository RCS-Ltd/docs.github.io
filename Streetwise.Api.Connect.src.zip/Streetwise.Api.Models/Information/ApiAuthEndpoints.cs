﻿namespace Streetwise.Api.Models
{
    public static class ApiAuthEndpoints
    {
        public const string Login = "api/ApiAuthenticate/Login";
        public const string RenewToken = "api/ApiAuthenticate/RenewToken";
    }
}
