﻿using System;
using System.Collections.Generic;

namespace Streetwise.Api.Models
{
    public class OnlineOrderInformation
    {
        public OrderInfo OrderInfo { get; set; }
        public List<OrderItemInfo> Items { get; set; }
        public List<OnlineOrderNoteDto> Notes { get; set; }

        public OnlineOrderDeliveryAddressDto DeliveryAddress { get; set; }
    }

    public class OrderInfo : OnlineOrderDto
    {
        
    }

    public class OrderItemInfo : OnlineOrderItemsDto
    {
        public string ProductName { get; set; }
        public DateTime? CancelOrRefundedUtc { get; set; }
    }

}
