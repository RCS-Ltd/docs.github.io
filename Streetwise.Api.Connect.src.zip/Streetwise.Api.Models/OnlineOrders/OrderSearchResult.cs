﻿using System;

namespace Streetwise.Api.Models
{
    public class OrderSearchResult
    {
        public int Id { get; set; }
        public decimal OrderTotal { get; set; }
        public string LocationCode { get; set; }
        public DateTime? DeliveryDate { get; set; }
        public int OrderStatusCode { get; set; }
        public string OrderGuid { get; set; }
        public int OrderId { get; set; }
        public DateTime OrderDateUtc { get; set; }
        public int RowCount { get; set; }
        public string OrderStatus { get; set; }
        public string StreetwiseOrderId { get; set; }
    }
}
