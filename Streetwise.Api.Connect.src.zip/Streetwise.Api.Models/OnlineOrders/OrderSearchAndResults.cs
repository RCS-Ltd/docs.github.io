﻿using System;
using System.Collections.Generic;

namespace Streetwise.Api.Models
{
    public class OrderSearchAndResults
    {
        /// <summary>
        /// The Results of the search
        /// </summary>
        public List<OrderSearchResult> Results { get; set; }

        /// <summary>
        /// List of available status
        /// </summary>
        public List<string> StatusValues { get; set; }

        /// <summary>
        /// List of status types to search for
        /// </summary>
        public List<string> SearchStatus { get; set; }

        /// <summary>
        /// Daterange search   Start date of range
        /// </summary>
        public DateTime? StartRange { get; set; }

        /// <summary>
        /// Date range search, end of search range
        /// </summary>
        public DateTime? EndRange { get; set; }

        /// <summary>
        /// Specific location to search for
        /// </summary>
        public string LocationCode { get; set; }
    }
}
