﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Streetwise.Api.Models
{
    public class DepartmentGroup : BaseStringIdModel
    {
        public string Name { get; set; }
    }
}
