﻿namespace Streetwise.Api.Models
{
    public class BaseStringIdModel
    {
        public string Id { get; set; }
    }
}
