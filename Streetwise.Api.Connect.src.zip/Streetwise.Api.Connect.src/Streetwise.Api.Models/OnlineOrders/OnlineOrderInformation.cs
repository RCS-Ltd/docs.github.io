﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;

namespace Streetwise.Api.Models
{
    public class OnlineOrderInformation
    {
        public OrderInfo OrderInfo { get; set; }
        public List<OrderItemInfo> Items { get; set; }
        public List<OnlineOrderNoteDto> Notes { get; set; }
        public OnlineOrderDeliveryAddressDto DeliveryAddress { get; set; }
    }

    public class OrderInfo : OnlineOrderDto
    {
        public string StatusMessage => ((OrderStatus) OrderStatus).ToString();
    }

    public class OrderItemInfo : OnlineOrderItemsDto
    {
        public string ProductName { get; set; }
        public DateTime? CancelOrRefundedUtc { get; set; }
        public string Size { get; set; }
        public string Barcode { get; set; }
        public int LineStatus { get; set; }
        public decimal RowTotal => PurchasePrice * PickedQty ?? 0;

        public string StatusMessage => ((OrderItemStatus) LineStatus).ToString();

        public string DisplayName => $"{ProductName} - {Barcode} - {ProductCode}";
    }

}
