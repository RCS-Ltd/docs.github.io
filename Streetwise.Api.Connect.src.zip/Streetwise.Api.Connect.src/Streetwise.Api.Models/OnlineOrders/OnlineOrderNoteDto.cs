﻿using System;

namespace Streetwise.Api.Models
{
    public class OnlineOrderNoteDto : BaseIntIdModel
    {
        public int OrderId { get; set; }
        public DateTime NoteDate { get; set; }
        public string Note { get; set; }
        public string WhoBy { get; set; }
    }
}
