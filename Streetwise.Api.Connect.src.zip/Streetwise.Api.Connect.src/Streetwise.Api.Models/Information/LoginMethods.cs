﻿namespace Streetwise.Api.Models
{
    public static class LoginMethods
    {
        public const string Basic = "Basic";
        public const string Token = "Token";
        public const string Bearer = "Bearer";
    }
}
