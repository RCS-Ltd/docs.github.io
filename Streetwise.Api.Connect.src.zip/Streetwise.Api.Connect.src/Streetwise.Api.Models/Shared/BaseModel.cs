﻿namespace Streetwise.Api.Models
{
    public class BaseModel
    {
        /// <summary>
        /// A valid acccess token, used to authenticate your request
        /// </summary>
        public string AccessToken { get; set; }
    }
}
