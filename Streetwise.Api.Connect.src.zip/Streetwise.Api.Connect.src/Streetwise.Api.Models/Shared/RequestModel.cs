﻿namespace Streetwise.Api.Models
{
    public class RequestModel : BaseModel
    {
        /// <summary>
        /// Serialize your data and add the output into the Data property
        /// </summary>
        public string Data { get; set; }

        public string LoginMethod { get; set; } = "Basic";
    }
}
